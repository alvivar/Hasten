﻿public class Tag
{
    public const string Player = "Player";
}
