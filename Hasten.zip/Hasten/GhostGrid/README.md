###GhostGrid v0.1.3.8
<br />

Lightweight grid component with auto snapping & additional magic. Just add
'GhostGrid.cs' to any GameObject to activate the grid for him and his
children.

Check out 'Tools/GhostGrid' in the menu for shortcuts!


<br /><br />
By [Andrés Villalobos](http://twitter.com/matnesis).
> 07/01/2015 3:21 am
