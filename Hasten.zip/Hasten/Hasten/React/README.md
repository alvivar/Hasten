# React

React is a *work-in-progress* Unity component for simple AI behaviour.
*Experimental, unstable, undocumented, use it at your own risk.*

> **[Andrés Villalobos](http://twitter.com/matnesis)**
