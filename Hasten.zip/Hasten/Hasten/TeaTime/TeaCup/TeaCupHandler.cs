
// @matnesis
// 2016/11/12 07:31 PM


namespace matnesis.TeaCup
{
    public class TeaCupHandler
    {
        public TeaCup self;


        public TeaCupHandler(TeaCup self)
        {
            this.self = self;
        }
    }
}