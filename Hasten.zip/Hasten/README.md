# Hasten

> _[Download](http://github.com/alvivar/Hasten/raw/master/Hasten.zip)_ | _[Say Hello](http://twitter.com/matnesis)_

This is the code I use in all [my games](http://matnesis.itch.io/). It's a
collection of scripts, extensions, patterns and custom tools I made for Unity.

I have managed to create all my stuff with versions of this, and I'm constantly
improving it with every new creation. Maybe you can find something useful, take
a look!
