
// I'm not sure if this is needed.

// @matnesis
// 2016/11/12 07:31 PM


namespace matnesis.TeaCup
{
    public class TeaCupHandler
    {
        public TeaCupQueue self;
    }
}
